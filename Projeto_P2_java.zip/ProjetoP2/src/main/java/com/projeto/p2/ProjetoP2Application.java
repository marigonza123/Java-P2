package com.projeto.p2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoP2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoP2Application.class, args);
	}

}
