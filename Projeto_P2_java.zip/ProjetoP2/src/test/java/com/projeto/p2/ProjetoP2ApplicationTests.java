package com.projeto.p2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoP2ApplicationTests {

	@Test
	void contextLoads() {
	}
}
